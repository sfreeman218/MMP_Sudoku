There are two directories within this project work, the MMP project, which holds the important class files for the
puzzle and solver classes

The solverTests directory contains three Junit test files and the experiment file(TestSolverComparison)